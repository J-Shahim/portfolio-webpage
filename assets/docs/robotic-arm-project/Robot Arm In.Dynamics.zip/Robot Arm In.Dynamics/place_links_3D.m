function link_set = place_links_3D(link_end_set_with_base, links_in_world)
% PLACE_LINKS_3D  Translate each link's local 3D geometry into world coordinates
% for the 3D prismatic arm.
%
% Inputs:
%   link_end_set_with_base : 1×(n+1) cell array, each entry is a 3×1 basepoint
%   links_in_world         : 1×n cell array, each entry is a 3×M local geometry
%
% Output:
%   link_set               : 1×n cell array, each entry is a 3×M geometry translated
%
% Notes:
% - Each local geometry (links_in_world{I}) is expressed with its base at [0;0;0].
% - This function offsets each geometry to the correct world basepoint
%   (link_end_set_with_base{I}).
% - Handles rigid (3×2) and prismatic (3×8 with NaN columns) links.

    n = numel(links_in_world);
    link_set = cell(1,n);

    for I = 1:n
        basepoint = link_end_set_with_base{I};   % 3×1 column vector
        geom      = links_in_world{I};           % 3×M matrix
        % Add basepoint to every column of geom
        link_set{I} = geom + repmat(basepoint,1,size(geom,2));
    end
end
