function [link_vectors,...
          joint_axes,...
          link_extensions,...
          prismatic,...
          T,...
          a_start,...
          sol,...
          alpha,...
          ax,...
          link_set,...
          l,...
          link_set_history] = ME317_Assignment_falling_arm_prismatic
% Make an animated plot of a robot arm with prismatic links falling under gravity

    %%%%%%%%%%%%%%%%%%%%%%%
    % Specify the system structure (link vectors, link_radii, and joint axes)

    % Specify link vectors as a 1x3 cell array of 3x1 vectors, named 'link_vectors'
    link_vectors = {[1 0 0]' [1 0 0]' [0 1 0]'};

    % Specify link radii as 1/20 the link length
    link_radii = [1/20, 1/20, 1/20]';

    % Specify joint axes as a cell array of the same size as link_vectors, named 'joint_axes'
    joint_axes = {'z' 'y' 'z'};

    % Specify link extensions as a 3x1 vector, named 'link_extensions'
    link_extensions = [0.0; 0.3; 0.2];

    % Specify which links are prismatic as a 3x1 vector named 'prismatic'
    % 0 = rigid, 1 = prismatic
    prismatic = [0; 1; 1];

    %%%%%%%%%%%%%%%%%%%%%%
    % Generate the system dynamics functions (inertia, derivative-of-inertia, and force)

    M_function = @(joint_angles) chain_inertia_matrix( ...
        link_vectors, joint_angles, joint_axes, link_radii);

    dM_function = matrix_derivative(M_function, length(joint_axes));

    F_function = @(time, configuration, velocity) gravitational_moment( ...
        link_vectors, configuration, joint_axes, velocity, link_radii) ...
        + joint_friction(velocity);

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Set up time-span and initial conditions for the simulation

    T = [0 30];
    a_start = zeros(size(joint_axes))';   % all joints start at 0 angle
    adot_start = zeros(size(a_start));    % all joints start at rest
    state_start = [a_start; adot_start];  % initial state vector

    %%%%%%%%%%%%%%%%%%%%%%
    % Evaluate the system motion

    state_velocity_function = @(time,state) EulerLagrange_trajectory( ...
        time, state, M_function, dM_function, F_function);

    sol = ode45(state_velocity_function, T, state_start);

    state_history = deval(sol, linspace(0,30,300));

    alpha    = state_history(1:end/2,:);         % joint angles
    alphadot = state_history(1+end/2:end,:);     %#ok<NASGU> % joint velocities (not used)

    %%%%%%%%%%%%%%%%%%%%%
    % Set up a figure in which to animate the motion

    ax = create_axes(8);
    link_colors = {'g',[0.5 0.5 0.5],'r'};

    % Generate link_set for the starting configuration
    [link_set,~,~] = threeD_robot_arm_links_prismatic( ...
        link_vectors, a_start, joint_axes, link_extensions, prismatic);

    % Draw a line (or 3 lines if prismatic) for each link
    l = threeD_draw_links(link_set, link_colors, ax);

    view(ax,3);
    axis(ax,'vis3d');
    axis(ax,[-0.5 3 -0.85 3.5 -4 1]);

    %%%%%%%%%%%%%%%%%%%%%%%
    % Animate the arm

    link_set_history = cell(1, length(alpha));

    for I = 1:length(alpha)
        % Get the line points for the arm at this time step
        [link_set,~,~] = threeD_robot_arm_links_prismatic( ...
            link_vectors, alpha(:,I), joint_axes, link_extensions, prismatic);

        % Update the illustration
        l = threeD_update_links(l, link_set);

        drawnow;

        % Save to history
        link_set_history{I} = link_set;
    end
    saveAnimationMP4(ax, 'falling_prismatic_arm.mp4', alpha, link_vectors, joint_axes, l, true, prismatic, link_extensions);

end
