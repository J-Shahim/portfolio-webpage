%{
    %%%%%%code to call%%%%%%%
link_vectors = {[1;0;0],[1;0;0],[0;0;1]};
joint_angles = [pi/4; -pi/2;1];
joint_axes = {'x','y','z'};
link_set = threeD_robot_arm_links(link_vectors,joint_angles,joint_axes);
ax = create_axes(317);

link_colors = {'r',[0.5 0.5 0.5],'k'};

l = draw_links(link_set,link_colors,ax);

view(ax,3)

link_set = threeD_robot_arm_links(link_vectors,joint_angles+1,joint_axes);
l = threeD_update_links(l,link_set)
%}
function l = threeD_update_links(l,link_set)
% Update the drawings of a set of lines for a link structure
%
% Inputs:
%
%   link_set: A 1xn cell array, each entry of which is a matrix whose
%       columns are the endpoints of the lines describing one link of the
%       system (as constructed by planar_build_links or
%       planar_build_links_prismatic
%
% Output:
%
%   l: A cell array of the same size as link_set, in which each entry is a
%       handle to a surface structure for that link


    %%%%%%%%
    % Loop over the lines whose handles are in 'l', replacing their 'XData',
    % 'YData', and 'ZData' with the information from 'link_set'
    for I=1:length(link_set)
       
        set(l{I},'Xdata',link_set{I}(1,:),'Ydata',link_set{I}(2,:),'Zdata',link_set{I}(3,:));

end
