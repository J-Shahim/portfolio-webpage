function [link_set,...
          R_joints,...
          R_links,...
          link_set_local,...
          link_vectors_in_world,...
          links_in_world,...
          link_end_set,...
          link_end_set_with_base] = threeD_robot_arm_links_prismatic(link_vectors,joint_angles,joint_axes,link_extensions,prismatic)
% Take a set of 3D link vectors, joint angles, and joint axes, and return
% a set of matrices for which the columns of each matrix are the endpoints
% of one of the links. Rigid links are drawn as one line, prismatic links
% as three lines.
%
% Inputs:
%   link_vectors: 1xn cell array, each element is a 3x1 link vector
%   joint_angles: nx1 vector, each element is the rotation about the joint axis
%   joint_axes:   nx1 cell array, each entry 'x','y','z'
%   link_extensions: nx1 vector of prismatic extension amounts
%   prismatic: nx1 vector of booleans, 1=prismatic, 0=rigid
%
% Outputs:
%   link_set:   1xn cell array, each entry is either 3x2 (rigid) or 3x? with NaN breaks (prismatic)
%   R_joints:   cell array of joint rotation matrices
%   R_links:    cell array of cumulative link orientations
%   link_set_local: local representation (with prismatic triple-lines if needed)
%   link_vectors_in_world: extended link vectors in world coords
%   links_in_world: link geometries rotated into world frame
%   link_end_set: endpoints of links in world coords
%   link_end_set_with_base: endpoints plus base [0;0;0]

    n = numel(link_vectors);

    %%%%%%%%
    % First, generate a cell array named 'R_joints' that contains a set of
    % rotation matrices corresponding to the joint angles and joint axes
    R_joints = cell(1,n);
    for i=1:n
        th = joint_angles(i);
        ax = joint_axes{i};
        switch ax
            case 'x'
                R_joints{i} = [1 0 0; 0 cos(th) -sin(th); 0 sin(th) cos(th)];
            case 'y'
                R_joints{i} = [cos(th) 0 sin(th); 0 1 0; -sin(th) 0 cos(th)];
            case 'z'
                R_joints{i} = [cos(th) -sin(th) 0; sin(th) cos(th) 0; 0 0 1];
        end
    end

    %%%%%%%%
    % Second, generate a cell array named 'R_links' that contains the
    % orientations of the link frames by taking cumulative products
    R_links = cell(1,n);
    R_links{1} = R_joints{1};
    for i=2:n
        R_links{i} = R_links{i-1} * R_joints{i};
    end

    %%%%%%%%
    % Third, build local link geometry. For rigid links this is [0 v].
    % For prismatic, construct the "rails" and "slider" (similar to
    % planar_build_links_prismatic, but now 3D). Save in 'link_set_local'.
    link_set_local = cell(1,n);
    for i=1:n
        v = link_vectors{i};
        if prismatic(i)==0
            link_set_local{i} = [zeros(3,1), v];
        else
            % Build prismatic rails and slider in the local frame
            L = norm(v);
            if L<eps
                link_set_local{i} = [zeros(3,1), v];
            else
                vhat = v/L;
                % pick arbitrary perpendicular directions to offset rails
                if abs(vhat(1))<0.9
                    tmp = [1;0;0];
                else
                    tmp = [0;1;0];
                end
                n1 = cross(vhat,tmp); n1 = n1/norm(n1);
                % scale base segment
                base_seg = [zeros(3,1), v];
                seg1 = 0.75*base_seg + (L/50)*n1*ones(1,2);
                seg2 = 0.75*base_seg - (L/50)*n1*ones(1,2);
                seg3 = 0.5*base_seg + (0.5*L+link_extensions(i))*vhat*ones(1,2);
                link_set_local{i} = [seg1, nan(3,1), seg2, nan(3,1), seg3];
            end
        end
    end

    %%%%%%%%
    % Fourth, extend link vectors by link_extensions for endpoints
    link_vectors_extended = cell(1,n);
    for i=1:n
        v = link_vectors{i};
        if prismatic(i)==1
            v = v + link_extensions(i)*(v/norm(v));
        end
        link_vectors_extended{i} = v;
    end

    %%%%%%%%
    % Fifth, rotate extended link vectors into world coordinates
    link_vectors_in_world = cell(1,n);
    for i=1:n
        link_vectors_in_world{i} = R_links{i} * link_vectors_extended{i};
    end

    %%%%%%%%
    % Sixth, rotate the local link geometries into world coordinates
    links_in_world = cell(1,n);
    for i=1:n
        links_in_world{i} = R_links{i} * link_set_local{i};
    end

    %%%%%%%%
    % Seventh, compute cumulative endpoints (link_end_set)
    link_end_set = cell(1,n);
    cum_sum = [0;0;0];
    for i=1:n
        cum_sum = cum_sum + link_vectors_in_world{i};
        link_end_set{i} = cum_sum;
    end

    %%%%%%%%
    % Eighth, add basepoint [0;0;0] to make link_end_set_with_base
    link_end_set_with_base = [{[0;0;0]}, link_end_set];

    %%%%%%%%
    % Ninth, place links by offsetting each rotated link geometry to the
    % correct base point. This requires a helper (like your 2D 'place_links').
    link_set = place_links_3D(link_end_set_with_base, links_in_world);

end
