function [link_vectors,...
          joint_angles,...
          joint_axes,...
          link_ends,...
          ax,...
          l] = ME317_Assignment_draw_3D_arm
% Draw a threee-dimensional arm as one line

    %%%%%%%%%%
    % Specify link vectors as a 1x3 cell array of 3x1 vectors, named
    % 'link_vectors'

    link_vectors={[1 0 0]' [1 0 0]' [0 0 0.5]'};

    %%%%%%%%%%
    % Specify joint angles as a 3x1 vector, named 'joint_angles'
    
    joint_angles=[2/5 -1/4 1/4]'*pi;

    %%%%%%%%%%
    % Specify joint axes as a 1x3 cell array, named 'joint_axes'

    joint_axes={'z' 'y' 'x'};

    %%%%%%%%%%
    % Get the endpoints of the links, in a cell array named 'link_ends'

    link_ends=threeD_robot_arm_endpoints(link_vectors,joint_angles,joint_axes);

    %%%%%%%%%
    % Create figure and axes for the plot, and store the handle in a
    % variable named 'ax'
    
    ax=create_axes(3);

    %%%%%%%%
    % Draw a line from the data, with circles at the endpoints, and save
    % the handle to this line in a variable named 'l'
     
    l=line('Xdata',link_ends(1,:),'Ydata',link_ends(2,:),'Zdata',link_ends(3,:),"Parent",ax,"Marker",'o',"linewidth",2);
    
    %%%%%%%%
    % Use the view(ax,3) command to set an angled view

    view(ax,3);
 

end