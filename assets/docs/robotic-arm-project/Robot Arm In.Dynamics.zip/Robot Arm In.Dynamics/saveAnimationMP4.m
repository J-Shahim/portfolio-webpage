
function saveAnimationMP4(ax, filename, alpha, link_vectors, joint_axes, l, isPrismatic, prismatic, link_extensions)
% saveAnimationMP4: Saves animated robot arm (revolute or prismatic) as MP4
%   ax             : plotting axis
%   filename       : output file name
%   alpha          : joint angles/positions over time (nJoints × nSteps)
%   link_vectors   : link vector definitions
%   joint_axes     : joint axis definitions
%   l              : handles to drawn links
%   isPrismatic    : true → prismatic version, false → revolute
%   prismatic      : 0/1 vector (same length as joints)
%   link_extensions: vector of prismatic extensions (same length as joints)

    nFrames = size(alpha,2);

    v = VideoWriter(filename,'MPEG-4');
    v.FrameRate = 20;  
    open(v);

    for i = 1:nFrames
        if isPrismatic
            % prismatic version (needs 5 inputs)
            link_set = threeD_robot_arm_links_prismatic(link_vectors, alpha(:,i), joint_axes, link_extensions, prismatic);
        else
            % revolute version (3 inputs only)
            link_set = threeD_robot_arm_links(link_vectors, alpha(:,i), joint_axes);
        end

        l = threeD_update_links(l, link_set);
        drawnow

        frame = getframe(ax);
        writeVideo(v, frame);
    end

    close(v);
    disp(['Animation saved as ', filename]);
end
