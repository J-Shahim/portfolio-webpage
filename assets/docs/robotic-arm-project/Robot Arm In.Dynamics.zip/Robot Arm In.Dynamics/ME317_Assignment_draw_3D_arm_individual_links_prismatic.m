function [link_vectors,...
          joint_angles,...
          joint_axes,...
          link_extensions,...
          prismatic,...
          link_colors,...
          link_set,...
          R_links,...
          joint_axis_vectors,...
          joint_axis_vectors_R,...
          ax,...
          l,...
          l3] = ME317_Assignment_draw_3D_arm_individual_links_prismatic
% Draw the 3D arm with one line per rigid link, and three lines per prismatic link

    %%%%%%%%%%
    % Specify link vectors as a 1x3 cell array of 3x1 vectors, named
    % 'link_vectors'
    link_vectors = {[1 0 0]' [1 0 0]' [0 0 0.5]'};

    %%%%%%%%%%
    % Specify joint angles as a 3x1 vector, named 'joint_angles'
    joint_angles = [2/5 -1/4 1/4]'*pi;

    %%%%%%%%%%
    % Specify joint axes as a 3x1 cell array, named 'joint_axes'
    joint_axes = {'z'; 'y'; 'x'};

    %%%%%%%%%%
    % Specify link extensions as a 3x1 vector, named 'link_extensions'
    link_extensions = [0.0; 0.3; 0.2];

    %%%%%%%%%%
    % Specify which links are prismatic as a 3x1 vector named 'prismatic',
    % with values of 0 for a rigid link or 1 for a link that can extend
    prismatic = [0; 1; 1];

    %%%%%%%%%%
    % Specify colors of links as a 1x3 cell array named 'link_colors'. Each
    % entry can be either a standard matlab color string (e.g., 'k' or 'r')
    % or a 1x3 vector of the RGB values for the color (range from 0 to 1)
    link_colors = {'g',[0.5 0.5 0.5],'r'};

    %%%%%%%%%
    % Generate a cell array named 'link_set' containing start-and-end
    % points for the links, taking into account prismatic links.
    % Also get R_links as an output.
    [link_set,~,R_links] = threeD_robot_arm_links_prismatic(...
        link_vectors,joint_angles,joint_axes,link_extensions,prismatic);

    % Use 'threeD_joint_axis_set' to turn the joint axes into
    % a set of axis vectors called 'joint_axis_vectors'
    joint_axis_vectors = threeD_joint_axis_set(joint_axes);

    % Use 'vector_set_rotate' to rotate the joint axes by the link
    % orientations. Call the output 'joint_axis_vectors_R'.
    joint_axis_vectors_R = vector_set_rotate(joint_axis_vectors,R_links);

    %%%%%%%%%
    % Create figure and axes for the plot, and store the handle in a
    % variable named 'ax'
    ax = create_axes(4);

    %%%%%%%%%
    % Draw a line (or three lines for prismatic) for each link, and save
    % the handles to these surfaces in a cell array named 'l'
    l = threeD_draw_links(link_set,link_colors,ax);

    %%%%%%%%%
    % Use 'view(ax,3)' to get a 3-dimensional view angle on the plot
    view(ax,3);
    % Use axis(ax,'vis3d') to make the arm stay the same size as you rotate
    axis(ax,'vis3d');

    %%%%%%%%%
    % Loop over the locations of the joints (the base points of the links),
    % and draw a dashed line from that joint to the point one unit from the
    % joint in the direction of that joint's axis.
    % Save the handles to these lines into a cell array called 'l3'.
    % As you make these lines, set their color property to be the same as
    % the link immediately after the joint
    l3 = cell(1,length(link_set));
    for I = 1:length(link_set)
        % Base point of link I is first column of link_set{I}
        base = link_set{I}(:,1);
        % Axis vector in world coordinates
        axis_vec = joint_axis_vectors_R{I};
        % End point one unit away
        endpt = base + axis_vec;

        l3{I} = line('XData',[base(1) endpt(1)], ...
                     'YData',[base(2) endpt(2)], ...
                     'ZData',[base(3) endpt(3)], ...
                     'Parent',ax, ...
                     'Marker','o', ...
                     'LineWidth',2, ...
                     'LineStyle','--', ...
                     'Color',link_colors{I});
    end
end
