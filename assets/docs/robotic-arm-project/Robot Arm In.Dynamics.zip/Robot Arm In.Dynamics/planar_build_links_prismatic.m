%{
link_vectors = {[1;0],[1;0],[0;5]};

link_extensions = [0;0.5;0.5];

prismatic = [0; 1; 1];

[link_set,link_normals] = planar_build_links_prismatic(link_vectors,link_extensions,prismatic);
link_set{:}
%}
function [link_set,...
    link_normals] = planar_build_links_prismatic(link_vectors,link_extensions,prismatic)
% Take a set of link vectors and augment each with a zero vector to form
% the base of the link. If the link is prismatic, represent the link as
% three lines: 
%   The base of the link is two lines that are each 3/4
% the zero-extension length of the link and are offset laterally (to the
% left and right) by a small amount from the line between the link start
% and endpoints.
%   The moving part of the link is a line 1/2 the zero-extension link
% length, and offset along the link vector by 1/2 the zero-extension length, plus
% the link extension
%
% Input:
%
%   link_vectors: a 1xn cell array, each element of which is the vector
%       from the base to end of a link, as seen in its *local* coordinate
%       frame 
%   link_extensions: a nx1 vector, each element of which is the extended 
%       length of the corresponding link.
%   prismatic: a nx1 vector, each element of which contains the information 
%        if the corresponding link is the prismatic or not, and
%        acts as a boolean.(0: false, 1: true)
%
% Outputs:
%
%   link_set: a 1xn cell array, each element of which is either:
%
%       1. A 2x2 matrix whose columns are the [0;0] base of the link in its
%       local frame and the link vector (end of the link) in its local
%       frame
%
%       or
%
%       2. A 2x8 matrix formed of three 2x2 matrices separated by 2x1 NaN
%       matrices. The columns of the three submatrices are the start and
%       endpoints of the three lines illustrating a prismatic link
%
%   link_normals: a cell array of the same size as link_vectors, containing
%       the unit normal vectors to the links


    %%%%%%%%%%%%%%
    % Use the 'cell' and 'size' commands to create an empty cell array the
    % same size as link_vectors named 'link_set'
    link_set=cell(size(link_vectors));
    %%%%%%%%%%%%%
    % Loop over the vectors in link_vectors, constructing a matrix whose
    % first column is all zeros and whose second column is the link vector,
    % and saving this matrix in the corresponding column of link_set
    for I=1:length(link_set)
        link_set{I}=[zeros(size(link_vectors{I})) link_vectors{I}];
    end
    %%%%%%%%%%%%%%
    % Create a normal vector for each link -- first create an empty cell
    % array the same size as link_vectors named 'link_normals', and then
    % loop over the link_vectors creating a unit-length vector that is
    % rotated 90 degrees with respect to the link vector
    link_normals=cell(size(link_vectors));
    for I=1:numel(link_vectors)
        v = link_vectors{I};
        if norm(v) < eps
            link_normals{I} = [0;0];
        else
            % rotate by +90°
            link_normals{I} = [0 -1; 1 0]*(v/norm(v));
        end
    end

    %%%%%%%%%%%%
    % Peform the extra operations to make nice-looking structures for the
    % prismatic joints:
    % 
    %   Loop over all vectors in link_set
    %
    %       Check if each link is prismatic. For the prismatic links, take
    %       the link matrix and
    % 
    for I=1:numel(link_set)
        if prismatic(I) == 1
            v = link_vectors{I};
            L = norm(v);
            if L < eps
                continue
            end
            n_hat = link_normals{I};
            base_seg = [zeros(size(v)) v];

            %           1. Scale it to 3/4 the link length
            seg1 = 0.75*base_seg;
            %           2. Add a vector 1/50 the link length in the link_normal
            %               direction to each column
            seg1 = seg1 + (L/50)*n_hat*ones(1,2);

            %           3. Make a second 3/4 scale copy of the link vector 
            seg2 = 0.75*base_seg;
            %           4. Add a vector 1/50 the link length in the *negative* 
            %               link_normal direction to each column of this second
            %               matrix
            seg2 = seg2 - (L/50)*n_hat*ones(1,2);

            %           5. Make a 1/2 scale copy of the link vector
            seg3 = 0.5*base_seg;
            %           6. Add a vector 1/2 the zero-extension link length plus the
            %               link extension amount in the direction of the link to
            %               each column of this third matrix
            v_hat = v/L;
            seg3 = seg3 + (0.5*L + link_extensions(I))*v_hat*ones(1,2);

            %           7. Join the three resulting 2x2 matrices together into a
            %               2x8 matrix, using 2x1 NaN matrices as spacers.
            link_set{I} = [seg1, nan(2,1), seg2, nan(2,1), seg3];
        end
    end

end
