function [link_vectors,...
          joint_axes,...
          link_extensions,...
          prismatic,...
          shape_to_draw,...
          J,...
          joint_velocity,...
          T,...
          a_start,...
          sol,...
          alpha,...
          ax,...
          link_colors,...
          link_set,...
          l,...
          p,...
          l_trace,...
          link_set_history] = Trace_circle_prismatic
% Prismatic-rendered arm that traces the same circle as the non-prismatic one
% by locking prismatic DOFs for control (extensions held constant).

    %%%%%%%%%%
    % Geometry
    link_vectors = {[1 0 0]' [1 0 0]' [0.75 0 0]'};   % same as rigid case
    joint_axes   = {'z' 'y' 'y'};
    link_extensions = [0.0; 0.2; 0.3];                % constant slider offsets to draw
    prismatic   = [0; 1; 1];                           % which links draw as prismatic

    % === Effective rigid link vectors for CONTROL (include constant extension) ===
    link_vectors_eff = link_vectors;
    for k = 1:numel(link_vectors)
        if prismatic(k)==1
            v = link_vectors{k};
            link_vectors_eff{k} = v + link_extensions(k)*(v/norm(v));
        end
    end

    %%%%%%%%%%
    % Circle trajectory (4 loops, radius 0.5 about x-axis)
    shape_to_draw = @(t) (circle_x(4*t))/2;

    % Jacobian for CONTROL uses rigid kinematics with effective lengths
    J = @(q) arm_Jacobian(link_vectors_eff, q, joint_axes, 3);

    % Velocity command
    joint_velocity = @(t,alpha) follow_trajectory(t,alpha,J,shape_to_draw);

    %%%%%%%%%%
    % Time + ICs
    T       = [0 4];                       % 4 cycles
    a_start = [0; pi/4; -pi/2];
    sol     = ode45(joint_velocity, T, a_start);
    alpha   = deval(sol, linspace(0,4,400));   % 400 frames (smooth)

    %%%%%%%%%%
    % Figure + initial draw (PRISMATIC for visualization)
    ax = create_axes(7);
    link_colors = {'g',[0.5 0.5 0.5],'r'};

    [link_set,~,~] = threeD_robot_arm_links_prismatic( ...
        link_vectors, a_start, joint_axes, link_extensions, prismatic);
    l = threeD_draw_links(link_set,link_colors,ax);

    %%%%%%%%%%
    % Trace path using PRISMATIC endpoints (correct with extensions)
    nFrames = size(alpha,2);
    p = zeros(3,nFrames);
    link_end_set_with_base = cell(1,nFrames);

    for I=1:nFrames
        [~,~,~,~,~,~,~,lewb] = threeD_robot_arm_links_prismatic( ...
            link_vectors, alpha(:,I), joint_axes, link_extensions, prismatic);
        link_end_set_with_base{I} = lewb;
        p(:,I) = lewb{end};
    end

    l_trace = line('XData',p(1,:),'YData',p(2,:),'ZData',p(3,:), ...
                   'Parent',ax,'Color','k');

    view(ax,3);
    axis(ax,'vis3d');
    axis(ax,'manual');

    %%%%%%%%%%
    % Animate (PRISMATIC draw, CONTROL angles)
    link_set_history = cell(1,nFrames);
    for I=1:nFrames
        [link_set,~,~] = threeD_robot_arm_links_prismatic( ...
            link_vectors, alpha(:,I), joint_axes, link_extensions, prismatic);
        l = threeD_update_links(l,link_set);
        drawnow
        link_set_history{I} = link_set;
    end

    %%%%%%%%%%
    % Save MP4 (PRISMATIC draw)
    saveAnimationMP4(ax, 'trace_circle_prismatic.mp4', alpha, ...
                     link_vectors, joint_axes, l, true, prismatic, link_extensions);
end
