%{
link_vectors = {[1;0],[1;0],[0;1]};
joint_angles = [pi/4; -pi/2;pi/7];
link_extensions = [0; 0; .5];
prismatic = [0; 1; 1];
link_set = planar_robot_arm_links_prismatic(link_vectors,joint_angles,link_extensions,prismatic);
link_set{:}
%}
function [link_set,...
            R_joints,...
            R_links,...
            link_set_local,...
            link_vectors_in_world,...
            links_in_world,...
            link_end_set,...
            link_end_set_with_base] = planar_robot_arm_links_prismatic(link_vectors,joint_angles, link_extensions, prismatic)
% Take a set of link vectors and joint angles, and return a set of matrices
% for which the columns of each matrix are the endpoints of one of the links.
%
% Inputs:
%
%   link_vectors: a 1xn cell array, each element of which is a 2x1 vector
%       describing the vector from the base of the corresponding link to
%       its end
%   joint_angles: a nx1 vector, each element of which is the joint angle
%       preceeding the corresponding link
%   link_extensions: a nx1 vector, each element of which is the extended 
%       length of the corresponding link.
%   prismatic: a nx1 vector, each element of which contains the information 
%        if the corresponding link is the prismatic or not, and
%        acts as a boolean.(0: false, 1: true)
%
% Outputs:
%
%   link_set: a 1xn cell array, each element of which is either
%       - a 2x2 matrix [0 v] for rigid links, or
%       - a 2x8 matrix (3 subsegments + NaN) for prismatic links
%
% Additional outputs are intermediates useful for debugging.

    n = numel(link_vectors);

    %%%%%%%%
    % First, generate a cell array named 'R_joints' that contains a set of
    % rotation matrices corresponding to the joint angles
    R_joints = cell(1,n);
    for i = 1:n
        th = joint_angles(i);
        R_joints{i} = [cos(th) -sin(th); sin(th) cos(th)];
    end
    
    %%%%%%%%
    % Second, generate a cell array named 'R_links' that contains the
    % orientations of the link frames by taking the cumulative products of
    % the joint rotation matrices
    R_links = cell(1,n);
    R_links{1} = R_joints{1};
    for i = 2:n
        R_links{i} = R_links{i-1} * R_joints{i};
    end
    
    %%%%%%%%
    % Third, use 'planar_build_links_prismatic' to generate a cell array named 
    % 'link_set_local' that contains the endpoint-sets for the links (a matrix
    %  whose columns are a zero vector and the link vector
    [link_set_local,~] = planar_build_links_prismatic(link_vectors,link_extensions,prismatic);
    
    %%%%%%%%
    % Fourth, generate a cell array named 'link_vectors_extended' that
    % contains the link vectors extended by the values in link_extensions
    link_vectors_extended = cell(1,n);
    for i = 1:n
        v = link_vectors{i};
        if prismatic(i) == 1
            v = v + link_extensions(i) * (v/norm(v));
        end
        link_vectors_extended{i} = v;
    end
    
    %%%%%%%%
    % Fifth, generate a cell array named 'link_vectors_in_world' that
    % contains the (extended) link vectors rotated by the rotation matrices for the
    % links
    link_vectors_in_world = cell(1,n);
    for i = 1:n
        link_vectors_in_world{i} = R_links{i} * link_vectors_extended{i};
    end
    
    %%%%%%%%
    % Sixth, generate a cell array named 'links_in_world' that contains the
    % link endpoint-set matrices rotated by the rotation matrices for the
    % links (the extension of these matrices should already have been
    % handled by planar_build_links_prismatic)
    links_in_world = cell(1,n);
    for i = 1:n
        links_in_world{i} = R_links{i} * link_set_local{i};
    end
    
    %%%%%%%%
    % Seventh, generate a cell array named 'link_end_set' that contains the
    % endpoints of each link, found by taking the cumulative sum of the
    % link vectors
    link_end_set = cell(1,n);
    cum_sum = [0;0];
    for i = 1:n
        cum_sum = cum_sum + link_vectors_in_world{i};
        link_end_set{i} = cum_sum;
    end
    
    %%%%%%%%
    % Eighth, add a cell containing a zero vector (for the origin point at
    % the base of the first link) to the beginning of link_end_set, saving
    % the result in a cell array named 'link_end_set_with_base'
    link_end_set_with_base = [{[0;0]}, link_end_set];
    
    %%%%%%%%
    % Ninth, generate a cell array named 'link_set' by adding the
    % basepoint of each link to the start-and-end matrices of that link
    % using 'place_links'
    link_set = place_links(link_end_set_with_base,links_in_world);

end
