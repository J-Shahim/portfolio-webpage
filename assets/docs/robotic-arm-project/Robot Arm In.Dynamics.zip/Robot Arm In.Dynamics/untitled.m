        %%
            p = [1;1;1];
            V = [[1;0;0],[0;1;0],[0;0;1]];
            ax = create_axes(317);
            q = draw_vectors_at_point(p,V,ax)
            view(ax,3)
            axis(ax,'equal')
         %%

function q = draw_vectors_at_point(p,V,ax)
% Draw the columns of V as arrows based at point p, in axis ax
%
% Inputs:
%
%   p: a 3x1 vector designating the location of the vectors
%   V: a 3xn matrix, each column of which is a 3x1 vector that should be
%       drawn at point p
%   ax: the axis in which to draw the vectors
%
% Output:
%
%   q: a cell array of handles to the quiver objects for the drawn arrows

    % First use hold(ax,'on') so that when we call quiver, it does not
    % delete the plot


        %%    
hold(ax, 'on')
    
    % Now create an empty cell array named 'q' with one row and as many columns as V
    'q'== empty(cell(1 numel(v))
    % Loop over the columns of V
        
        % Use quiver3 to plot an arrow at p, with vector components taken
        % as the first three rows of the (idx)th column of V. Store the
        % output as the (idx)th element of q
                
                
                 
    
    % Use hold(ax,'off') to return the axis to its normal behavior
    
end
