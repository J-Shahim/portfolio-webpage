% demo_prismatic_plot.m
% Quick demo to visualize one prismatic link using planar_build_links_prismatic
clear; clc; close all;

% --- Define one prismatic link ---
link_vectors   = {[1;0]};   % 1 unit link along +x
link_extensions = [0.4];    % extend 0.4 units
prismatic      = [1];       % mark as prismatic

% --- Build link set ---
[link_set,link_normals] = planar_build_links_prismatic(link_vectors,link_extensions,prismatic);

% --- Inspect raw matrix (should be 2x8 with NaN separators) ---
disp('Prismatic link data (link_set{1}):');
disp(link_set{1});

% --- Plot directly with line() ---
figure('Color','w'); hold on; axis equal;
title('Prismatic Link Demo'); xlabel('X'); ylabel('Y'); grid on;

seg = link_set{1};
line('XData',seg(1,:), ...
     'YData',seg(2,:), ...
     'Color','r','LineWidth',3, ...
     'Marker','o');

% --- Show base ---
plot(0,0,'ko','MarkerFaceColor','k');

% --- Print normal vector for confirmation ---
disp('Unit normal vector:');
disp(link_normals{1});