function [J,...
          link_ends,...
          link_end_set,...   
          link_end_set_with_base,...
          v_diff,...
          joint_axis_vectors,...
          joint_axis_vectors_R,...
          R_links] = arm_Jacobian_prismatic(link_vectors,joint_angles,joint_axes,link_number,prismatic)
% Construct a Jacobian for a chain of links (revolute and prismatic)
% as a function of the link vectors, joint angles/positions, joint axes,
% prismatic flags, and the link endpoint of interest.
%
% Inputs:
%   link_vectors : 1xn cell array, each entry is a 3x1 link vector
%   joint_angles : nx1 vector, revolute angles [rad] or prismatic displacements
%   joint_axes   : 1xn cell array, each 'x','y','z' axis for the joint
%   link_number  : link index for Jacobian evaluation
%   prismatic    : nx1 vector, 0 = revolute, 1 = prismatic
%
% Output:
%   J : 3×n Jacobian of end-effector velocity wrt joint velocities

    % Compute link endpoints and orientations
    [link_ends,~,R_links,~,link_end_set,link_end_set_with_base] = ...
        threeD_robot_arm_endpoints(link_vectors,joint_angles,joint_axes);

    % Vector from each joint location to target link endpoint
    v_diff = vector_set_difference(link_end_set_with_base{link_number+1}, link_end_set_with_base);

    % Joint axis unit vectors in local coordinates
    joint_axis_vectors = threeD_joint_axis_set(joint_axes);

    % Rotate into world coordinates
    joint_axis_vectors_R = vector_set_rotate(joint_axis_vectors, R_links);

    % Initialize Jacobian
    J = zeros(3, numel(joint_axis_vectors_R));

    % Convert to symbolic if needed
    for I=1:length(joint_axis_vectors_R)
        if isa(joint_axis_vectors_R{I},'sym') || isa(v_diff{I},'sym')
            J = sym(J);
        end
    end

    % Fill Jacobian columns
    for I=1:link_number
        if prismatic(I) == 0
            % Revolute: cross(axis, vector to end-effector)
            J(:,I) = cross(joint_axis_vectors_R{I}, v_diff{I});
        else
            % Prismatic: axis vector directly
            J(:,I) = joint_axis_vectors_R{I};
        end
    end
end
